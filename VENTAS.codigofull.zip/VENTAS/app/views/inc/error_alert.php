<article class="message is-danger">
	 <div class="message-header">
	    <p>¡Ocurrio un error inesperado!</p>
	 </div>
    <div class="message-body has-text-centered"><i class="fas fa-exclamation-triangle fa-2x"></i><br>No se pudo cargar los datos solicitados</div>
</article>