<?php

	const DB_SERVER="localhost";
	const DB_NAME="ventas";
	const DB_USER="root";
	const DB_PASS='';